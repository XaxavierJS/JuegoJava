package puppy.code;

public interface EffectApplier {
    void applyEffect(PantallaJuego gameScreen);
}
